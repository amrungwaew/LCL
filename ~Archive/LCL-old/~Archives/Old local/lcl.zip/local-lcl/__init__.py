import jax.numpy as jnp
import numpy as onp
import polars as pl
from lcl.latent_class_conditional_logit import LatentClassConditionalLogit
